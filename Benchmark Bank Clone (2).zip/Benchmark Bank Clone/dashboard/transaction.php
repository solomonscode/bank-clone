<?php
session_start();
// $_SESSION["FIRSTNAME"] ;
// $_SESSION["LASTNAME"];
// $_SESSION["EMAIL"];
// $_SESSION["BALANCE"];
// print_r($_SESSION["USER"])

if (empty($_SESSION["CODE"])) {
    header("location:../index.php");
    die("unAuthorized access");
    // header("location:index.php");
}
if (!empty($err)) {
    $err = $_SESSION["ERROR"];
}

// $err = $_SESSION["ERROR"];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transactions</title>
    <link rel="shortcut icon" href="./images/fcb usa.png" type="image/x-icon">
    <!-- bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <!-- ----- --- Font-awesome ---- -----  -->
    <link rel="stylesheet" href="./fontawesome-free-6.3.0-web/css/fontawesome.css">
    <link rel="stylesheet" href="./fontawesome-free-6.3.0-web/css/brands.css">
    <link rel="stylesheet" href="./fontawesome-free-6.3.0-web/css/solid.css">
    <link rel="stylesheet" href="./fontawesome-free-6.3.0-web/css/all.css">
</head>

<body>
    <div class="container-fluid">
        <nav class="navbar navbar-expand-lg bg-body-tertiary">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">
                    <img src="./images/logo.png" alt="logo">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
                    <ul class="navbar-nav nav-pills nav-fill me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="./index.php"><i class="fa-regular fa-grid-2-plus"></i> Dashboard</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./maketransfer.php">Make Transfer</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active text-white" href="./transaction.php"> Transactions </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./profile.php"> Profile</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./mybalance.php"> My Balance </a>
                        </li>
                    </ul>
                    <div class="nav-item me-2">
                        <a class="nav-link me-2 fw-bold link-primary" href="./logout.php"> LOG OUT </a>
                    </div>
                </div>

                <div class="d-flex">
                    <label>
                        <h4 class="font-monospace"> Hello, </h4>
                    </label>
                    <h2>
                        <label class="me-1"> <?php echo ($_SESSION["USER"]['first_name'])  ?> </label> <?php echo ($_SESSION["USER"]['last_name'])  ?> </label>
                    </h2>
                    <div class="ms-2">
                        <a href="#">
                            <div class="text-center">
                                <img src="./images/Image n r.png" class="rounded-circle" alt="Profile pic" width="50" height="50" />
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </nav>
        <!-- /. End of Nav -----  -->

        <!-- ------ Content -----     -->
        <div class="container p-3">
            <br>
            <div class="card p-3">
                <p class="fs-1 p-2">Transaction's list</p>
                <div class="card-body table-responsive">
                    <table class="table table-striped table-hover">
                        <thead class="fw-bold text-info-emphasis">
                            <tr>
                                <th scope="col align-items-center text-center" colspan="2">
                                    <center> Transaction #IDs </center>
                                </th>
                                <th scope="col"> Account Number</th>
                                <th scope="col">Amount</th>
                                <th scope="col"> Balance</th>
                                <th scope="col">Details </th>
                                <th scope="col"> TYPE</th>
                                <th scope="col"> <i class="fa-regular fa-circle-ellipsis"></i></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th scope="row">
                                    <div class="row align-items-center" style="overflow: auto;">
                                        <div class="col text-info-emphasis text-center align-middle fs-1"><i class="fa-regular fa-circle-check"></i></div>
                                        <div class="col">
                                            <b>GLHUm4v2YU</b>
                                            <p class="text-body-tertiary"> 25 Feb, 2023 04:41pm</p>
                                        </div>
                                    </div>
                                </th>
                                <!-- <td>&nbsp;</td> -->
                                <td>&nbsp;</td>
                                <td><b>HollyWood HQ</b>
                                    <p class="text-body-tertiary">76533112055</p>
                                </td>
                                <td>
                                    <p class="text-body-tertiary"> 252,000.00 USD</p>
                                </td>
                                <td><b>3,803,099.00 USD</b>
                                </td>
                                <td>
                                    <b>Sponsorship Contract</b>
                                    <p class="text-body-tertiary">United States</p>
                                </td>
                                <td class="text-info-emphasis text-center align-middle">
                                    <div class="border border-success p-2 mb-2 border-opacity-75"> Wire Transfer </div>
                                </td>
                                <td class="fs-2 text-center align-middle">
                                    <i class="fa-sharp fa-regular fa-eye"></i>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <div class="row align-items-center" style="overflow: auto;">
                                        <div class="col text-info-emphasis text-center align-middle fs-1"><i class="fa-regular fa-circle-check"></i></div>
                                        <div class="col">
                                            <b>TXNzm4vxMP</b>
                                            <p class="text-body-tertiary"> 05 Feb, 2023 11:47am </p>
                                        </div>
                                    </div>
                                </th>
                                <!-- <td>&nbsp;</td> -->
                                <td>&nbsp;</td>
                                <td><b>Calvin Klein</b>
                                    <p class="text-body-tertiary">31239621377</p>
                                </td>
                                <td>
                                    <p class="text-body-tertiary"> 172,740.00 USD</p>
                                </td>
                                <td><b>3,503,899.00 USD</b>
                                </td>
                                <td>
                                    <b>Sponsorship</b>
                                    <p class="text-body-tertiary">United State</p>
                                </td>
                                <td class="text-info-emphasis text-center align-middle">
                                    <div class="border border-success p-2 mb-2 border-opacity-75"> Instant Transfer </div>
                                </td>
                                <td class="fs-2 text-center align-middle">
                                    <i class="fa-sharp fa-regular fa-eye"></i>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <div class="row align-items-center" style="overflow: auto;">
                                        <div class="col text-info-emphasis text-center align-middle fs-1"><i class="fa-regular fa-circle-check"></i></div>
                                        <div class="col">
                                            <b>TRFm4vs2JB</b>
                                            <p class="text-body-tertiary"> 19 Jan, 2023 06:48pm</p>
                                        </div>
                                    </div>
                                </th>
                                <!-- <td>&nbsp;</td> -->
                                <td>&nbsp;</td>
                                <td><b>Paris Airport France</b>
                                    <p class="text-body-tertiary">37121012503</p>
                                </td>
                                <td>
                                    <p class="text-body-tertiary">102,900.00 USD</p>
                                </td>
                                <td><b>3,103,899.00 USD</b>
                                </td>
                                <td>
                                    <b>Cash Withdrawal</b>
                                    <p class="text-body-tertiary">France</p>
                                </td>
                                <td class="text-info-emphasis text-center align-middle">
                                    <div class="border border-success p-2 mb-2 border-opacity-75"> Instant Transfer </div>
                                </td>
                                <td class="fs-2 text-center align-middle">
                                    <i class="fa-sharp fa-regular fa-eye"></i>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <div class="row align-items-center" style="overflow: auto;">
                                        <div class="col text-info-emphasis text-center align-middle fs-1"><i class="fa-regular fa-circle-check"></i></div>
                                        <div class="col">
                                            <b>DDxxxxx715</b>
                                            <p class="text-body-tertiary"> 24 Dec, 2022 07:42am</p>
                                        </div>
                                    </div>
                                </th>
                                <!-- <td>&nbsp;</td> -->
                                <td>&nbsp;</td>
                                <td><b>Atlanta Airport USA</b>
                                    <p class="text-body-tertiary">231211120525</p>
                                </td>
                                <td>
                                    <p class="text-body-tertiary">68,900.00 USD</p>
                                </td>
                                <td><b>3,210,261.50 USD</b>
                                </td>
                                <td>
                                    <b>031735233076</b>
                                    <p class="text-body-tertiary">United States</p>
                                </td>
                                <td class="text-info-emphasis text-center align-middle">
                                    <div class="border border-success p-2 mb-2 border-opacity-75"> Card Payment </div>
                                </td>
                                <td class="fs-2 text-center align-middle">
                                    <i class="fa-sharp fa-regular fa-eye"></i>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <div class="row align-items-center" style="overflow: auto;">
                                        <div class="col text-info-emphasis text-center align-middle fs-1"><i class="fa-regular fa-circle-check"></i></div>
                                        <div class="col">
                                            <b>DDxxxxx305</b>
                                            <p class="text-body-tertiary"> 14 Dec, 2022 07:21am</p>
                                        </div>
                                    </div>
                                </th>
                                <!-- <td>&nbsp;</td> -->
                                <td>&nbsp;</td>
                                <td><b>Disney World LLC</b>
                                    <p class="text-body-tertiary">401268320583</p>
                                </td>
                                <td>
                                    <p class="text-body-tertiary">48,000.00 USD</p>
                                </td>
                                <td><b>3,498,261.50 USD</b>
                                </td>
                                <td>
                                    <b>Monthly Salary</b>
                                    <p class="text-body-tertiary">United States</p>
                                </td>
                                <td class="text-info-emphasis text-center align-middle">
                                    <div class="border border-success p-2 mb-2 border-opacity-75"> Direct Deposit </div>
                                </td>
                                <td class="fs-2 text-center align-middle">
                                    <i class="fa-sharp fa-regular fa-eye"></i>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <div class="row align-items-center" style="overflow: auto;">
                                        <div class="col text-info-emphasis text-center align-middle fs-1"><i class="fa-regular fa-circle-check"></i></div>
                                        <div class="col">
                                            <b>Qmg4v5Eol</b>
                                            <p class="text-body-tertiary"> 21 Nov, 2022 03:41pm</p>
                                        </div>
                                    </div>
                                </th>
                                <!-- <td>&nbsp;</td> -->
                                <td>&nbsp;</td>
                                <td><b>Paris Hotel</b>
                                    <p class="text-body-tertiary">801168750589</p>
                                </td>
                                <td>
                                    <p class="text-body-tertiary">8,000.00 USD</p>
                                </td>
                                <td><b>3,420,181.00 USD</b>
                                </td>
                                <td>
                                    <b>Cash withdrawal</b>
                                    <p class="text-body-tertiary">France</p>
                                </td>
                                <td class="text-info-emphasis text-center align-middle">
                                    <div class="border border-success p-2 mb-2 border-opacity-75"> Card Payment
                                </td>
                                <td class="fs-2 text-center align-middle">
                                    <i class="fa-sharp fa-regular fa-eye"></i>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <div class="row align-items-center" style="overflow: auto;">
                                        <div class="col text-info-emphasis text-center align-middle fs-1"><i class="fa-regular fa-circle-check"></i></div>
                                        <div class="col">
                                            <b>GLHpn4x6IO</b>
                                            <p class="text-body-tertiary">15 Nov, 2022 03:37pm</p>
                                        </div>
                                    </div>
                                </th>
                                <!-- <td>&nbsp;</td> -->
                                <td>&nbsp;</td>
                                <td><b>Justin Bradford</b>
                                    <p class="text-body-tertiary">369068786597</p>
                                </td>
                                <td>
                                    <p class="text-body-tertiary">252,000.00 USD</p>
                                </td>
                                <td><b>3,503,099.10 USD</b>
                                </td>
                                <td>
                                    <b>child support</b>
                                    <p class="text-body-tertiary">United States</p>
                                </td>
                                <td class="text-info-emphasis text-center align-middle">
                                    <div class="border border-success p-2 mb-2 border-opacity-75"> Instant Transfer</div>
                                </td>
                                <td class="fs-2 text-center align-middle">
                                    <i class="fa-sharp fa-regular fa-eye"></i>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <div class="row align-items-center" style="overflow: auto;">
                                        <div class="col text-info-emphasis text-center align-middle fs-1"><i class="fa-regular fa-circle-check"></i></div>
                                        <div class="col">
                                            <b>GLHQ2g3vRs</b>
                                            <p class="text-body-tertiary">15 Oct, 2022 02:21pm</p>
                                        </div>
                                    </div>
                                </th>
                                <!-- <td>&nbsp;</td> -->
                                <td>&nbsp;</td>
                                <td><b>Taylor Bradford</b>
                                    <p class="text-body-tertiary">801168746597</p>
                                </td>
                                <td>
                                    <p class="text-body-tertiary">112,000.00 USD</p>
                                </td>
                                <td><b>3,928,199.00 USD</b>
                                </td>
                                <td>
                                    <b>000236674190</b>
                                    <p class="text-body-tertiary">United States</p>
                                </td>
                                <td class="text-info-emphasis text-center align-middle">
                                    <div class="border border-success p-2 mb-2 border-opacity-75"> Wire Transfer</div>
                                </td>
                                <td class="fs-2 text-center align-middle">
                                    <i class="fa-sharp fa-regular fa-eye"></i>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="row card-body">
                        <div class="col">
                            <div class="p-1">
                                Showing <a href="#"> <b> 1-8 </b></a> 0f <a href="#"> <b>200 </b> </a> trasactions.
                            </div>
                        </div>
                        <div class="col">
                            <div class="text-end p-1 align-item-middle">
                                <nav aria-label="Page navigation example">
                                    <ul class="pagination justify-content-end">
                                        <li class="page-item disabled">
                                            <a class="page-link">Previous</a>
                                        </li>
                                        <li class="page-item"><a class="page-link" href="#">1</a></li>
                                        <li class="page-item"><a class="page-link" href="#">2</a></li>
                                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                                        <li class="page-item"><a class="page-link" href="#">...</a></li>
                                        <li class="page-item">
                                            <a class="page-link" href="#">Next</a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <!-- ------========--------  -->

        <!-- -------- Footer ------------ -->
        <nav class="navbar fixed-bottom bg-body-tertiary">
            <div class="container-fluid">
                <div class="navbar-brand" href="#">
                    <label> <a href="#">Information.</a></label>
                    <label> <a href="#"> FAQ. </a></label>
                    <label><a href="#"> Privacy & Policy.</a></label>
                </div>
                <a class="navbar-brand" href="#"> &nbsp;</a>
                <div class="navbar-brand" href="#">
                    <label> <i class="fa-regular fa-copyright"></i> 2023 First Citizen Group Bank </label>
                    <label>ALL RIGHT RSERVED.</label>
                </div>
            </div>
        </nav>
    </div>

    <!-- ------ Conflict detect against Awesome fonts ------ -->
    <script type="text/javascript" src="https://example.com/fontawesome/v6.3.0/js/conflict-detection.js">
    </script>
    <!-- bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js" integrity="sha384-mQ93GR66B00ZXjt0YO5KlohRA5SY2XofN4zfuZxLkoj1gXtW8ANNCe9d5Y3eG5eD" crossorigin="anonymous"></script>
</body>

</html>