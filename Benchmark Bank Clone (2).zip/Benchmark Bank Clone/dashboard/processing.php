<?php

echo "<script>alert('Account-Restriction!!!   Loading...  Please try again... Contact account manager');</script>";

// gh();

// function gh(){
//     header("location:index.php");
// }