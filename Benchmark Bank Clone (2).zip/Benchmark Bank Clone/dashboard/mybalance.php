<?php
session_start();
// $_SESSION["FIRSTNAME"] ;
// $_SESSION["LASTNAME"];
// $_SESSION["EMAIL"];
// $_SESSION["BALANCE"];
// print_r($_SESSION["USER"])

if (empty($_SESSION["CODE"])) {
    header("location:../index.php");
    die("unAuthorized access");
    // header("location:index.php");
}
if (!empty($err)) {
    $err = $_SESSION["ERROR"];
}

// $err = $_SESSION["ERROR"];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link rel="shortcut icon" href="./images/fcb usa.png" type="image/x-icon">
    <!-- bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <!-- ----- --- Font-awesome ---- -----  -->
    <link rel="stylesheet" href="./fontawesome-free-6.3.0-web/css/fontawesome.css">
    <link rel="stylesheet" href="./fontawesome-free-6.3.0-web/css/brands.css">
    <link rel="stylesheet" href="./fontawesome-free-6.3.0-web/css/solid.css">
    <link rel="stylesheet" href="./fontawesome-free-6.3.0-web/css/all.css">
</head>

<body>
    <div class="container-fluid">
        <!-- ----=== Nav Bar ===---  -->
        <nav class="navbar navbar-expand-lg bg-body-tertiary">

            <div class="container-fluid">
                <a class="navbar-brand" href="#">
                    <img src="./images/logo.png" alt="logo">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
                    <ul class="navbar-nav nav-pills nav-fill me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="./index.php"><i class="fa-regular fa-grid-2-plus"></i> Dashboard</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./maketransfer.php">Make Transfer</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./transaction.php"> Transactions </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./profile.php"> Profile</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active text-white" href="./mybalance.php"> My Balance </a>
                        </li>
                    </ul>
                    <div class="nav-item me-2">
                        <a class="nav-link me-2 fw-bold link-primary" href="./logout.php"> LOG OUT </a>
                    </div>
                </div>

                <div class="d-flex">
                    <label>
                        <h4 class="font-monospace"> Hello, </h4>
                    </label>
                    <h2>
                        <label class="me-1"> <?php echo ($_SESSION["USER"]['first_name'])  ?> </label> <?php echo ($_SESSION["USER"]['last_name'])  ?> </label>
                    </h2>
                    <div class="ms-2">
                        <a href="#">
                            <div class="text-center">
                                <img src="./images/Image n r.png" class="rounded-circle" alt="Profile pic" width="50" height="50" />
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </nav>
        <!-- /. End of Nav -----  -->


        <!-- ------ Content -----     -->
        <div class="bg-body-secondary p-3"> <br />

            <div class="container-fluid p-3">
                <div class="row d-flex justify-content-between">
                    <div class=" col-lg-7 p-2">
                        <div class="container">
                            <div class="p-3">
                                <div class="card">
                                    <div class="card-body">
                                        <h3 class="text-tertiary p-2 fw-bold">
                                            My Account Summary
                                        </h3>
                                        <div class="border">
                                            <div class="row card-body">
                                                <div class="col-6 card-title fw-bold">
                                                    Account Balance
                                                    <h2 class="text-info">
                                                        3,820,280.00 USD
                                                    </h2>
                                                    <span class="text-secondary">
                                                        Equivalent to <b>3,120,322.69 EUR</b>
                                                    </span>
                                                </div>
                                                <div class="col-6">
                                                    <img src="./images/Image n r.png" class="rounded float-end" alt="Profile Pic" width="120" height="120">
                                                </div>
                                            </div>
                                            <br />
                                            <div class="row card-body p-3">
                                                <div class="col p-2">
                                                    <h2 class="text-info">
                                                        Account Type
                                                    </h2>
                                                    <p class="fs-2">
                                                        Checking
                                                    </p>
                                                    <span class="text-secondary">
                                                        Account Number:
                                                    </span><br />
                                                    <span class="fw-bold">
                                                        644765858755
                                                    </span>
                                                </div>
                                                <div class="col p-2 align-self-end">
                                                    <span class="text-secondary">
                                                        Email Address:
                                                    </span><br />
                                                    <span class="fw-bold">
                                                        verified.normanreedus.office@gmail.com
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                    <div class="col-lg-5 p-2">
                        <div class="p-1" style="max-width: 30rem;">
                            <div class="card p-2">
                                <div class="card-body p-3">
                                    <h5 class="text-info fw-bold">Your Account Info</h5>
                                    <span class="fs-3">Account Number: 644765858755</span><br>
                                    <span class="fs-3"> Bank Sort: 21-29-11</span>
                                    <div class="card-body">
                                        <h5 class="text-info"> Quick Transfer</h5>
                                        <p>Make A Transfer <a href="./maketransfer.php"> Now</a>.</p>
                                    </div>
                                </div>
                            </div>
                            <br />
                            <div class="card p-2">
                                <div class="card-body p-3">
                                    <h5 class="text-info fw-bold">
                                        Promotional offers
                                    </h5>
                                    <p>
                                        Register your e-mail address to get express delivery of the latest offers and earn a chance to win fabulous prize.
                                    </p>
                                    <p>
                                        To protect the environment and reduce paper consumption, please opt for e-statement service.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div><br>
        <!-- --------- ========= ------  -->

        <!-- -------- Footer ------------ -->
        <nav class="navbar fixed-bottom bg-body-tertiary">
            <div class="container-fluid">
                <div class="navbar-brand" href="#">
                    <label> <a href="#">Information.</a></label>
                    <label> <a href="#"> FAQ. </a></label>
                    <label><a href="#"> Privacy & Policy.</a></label>
                </div>
                <a class="navbar-brand" href="#"> &nbsp;</a>
                <div class="navbar-brand" href="#">
                    <label> <i class="fa-regular fa-copyright"></i> 2023 First Citizen Group Bank </label>
                    <label>ALL RIGHT RSERVED.</label>
                </div>
            </div>
        </nav>
    </div>

    <!-- ------ Conflict detect against Awesome fonts ------ -->
    <script type="text/javascript" src="https://example.com/fontawesome/v6.3.0/js/conflict-detection.js">
    </script>
    <!-- bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js" integrity="sha384-mQ93GR66B00ZXjt0YO5KlohRA5SY2XofN4zfuZxLkoj1gXtW8ANNCe9d5Y3eG5eD" crossorigin="anonymous"></script>
</body>

</html>