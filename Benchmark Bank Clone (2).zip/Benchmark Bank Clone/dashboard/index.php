<?php
session_start();
// $_SESSION["FIRSTNAME"] ;
// $_SESSION["LASTNAME"];
// $_SESSION["EMAIL"];
// $_SESSION["BALANCE"];
// print_r($_SESSION["USER"])

if (empty($_SESSION["CODE"])) {
    header("location:../index.php");
    die("unAuthorized access");
    // header("location:index.php");
}
if (!empty($err)) {
    $err = $_SESSION["ERROR"];
}

// $err = $_SESSION["ERROR"];
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="shortcut icon" href="./images/fcb usa.png" type="image/x-icon">
    <!-- bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <!-- ----- --- Font-awesome ---- -----  -->
    <link rel="stylesheet" href="./fontawesome-free-6.3.0-web/css/fontawesome.css">
    <link rel="stylesheet" href="./fontawesome-free-6.3.0-web/css/brands.css">
    <link rel="stylesheet" href="./fontawesome-free-6.3.0-web/css/solid.css">
    <link rel="stylesheet" href="./fontawesome-free-6.3.0-web/css/all.css">
</head>

<body>
    <div class="container-fluid">
        <!-- ----=== Nav Bar ===---  -->
        <nav class="navbar navbar-expand-lg bg-body-tertiary">

            <div class="container-fluid">
                <a class="navbar-brand" href="#">
                    <img src="./images/logo.png" alt="logo">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
                    <ul class="navbar-nav nav-pills nav-fill me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link active text-white" aria-current="page" href="./index.php"><i class="fa-regular fa-grid-2-plus"></i> Dashboard</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./maketransfer.php">Make Transfer</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./transaction.php"> Transactions </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./profile.php"> Profile</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./mybalance.php"> My Balance </a>
                        </li>
                    </ul>
                    <div class="nav-item me-2">
                        <a class="nav-link me-2 fw-bold link-primary" href="./logout.php"> LOG OUT </a>
                    </div>
                </div>

                <div class="d-flex">
                    <label>
                        <h4 class="font-monospace"> Hello, </h4>
                    </label>
                    <h2>
                        <label class="me-1"> <?php echo ($_SESSION["USER"]['first_name'])  ?> </label> <?php echo ($_SESSION["USER"]['last_name'])  ?> </label>
                    </h2>
                    <div class="ms-2">
                        <a href="#">
                            <div class="text-center">
                                <img src="./images/Image n r.png" class="rounded-circle" alt="Profile pic" width="50" height="50" />
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </nav>
        <!-- /. End of Nav -----  -->


        <!-- ------ Content -----     -->
        <div class="bg-body-secondary p-3"> <br />

            <div class="container p-3">
                <div class="row text-center">
                    <div class="col-md-4 themed-grid-col p-2">
                        <div class="card">
                            <div class="card-body bg-primary-subtle">
                                <div class="container text-center">
                                    <div class="row">
                                        <div class="col-sm-3 text-center">
                                            <img src="./images/dollar.png" alt="dollar sign" width="60" height="60">
                                        </div>
                                        <div class="col-sm-9 text-start">
                                            <h6 class="card-subtitle mb-2 text-info-emphasis fw-semibold">ACCOUNT BALANCE</h6>
                                            <h5 class="card-title"> <span class="fs-2"> 3,820,280.00 </span> <b> USD</b> <i data-bs-toggle="tooltip" title="Equivalent to ~ USD" class="fa-solid fa-circle-info"></i></h5>
                                        </div>
                                    </div>
                                </div>

                                <br />

                                <p class="card-text text-info-emphasis fw-semibold ">YOUR EQUIVALENT IN </p>
                                <a href="#" class="text-start">~3,820,280.00 USD</a>
                                <a href="#" class="card-link">~3,120,322.69 EUR </a>
                                <a href="#" class="card-link">~3,620,972.98 GBP</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4 themed-grid-col p-2">
                        <div class="card">
                            <h5 class="card-header fw-bold text-info-emphasis">Account Status &nbsp; <span class="text-bg-success p-1">RUNNING</span></h5>
                            <div class="card-body">
                                <h4 class="card-title fs-2">Last Transaction Status</h4>
                                <span class="border border-success p-1 text-uppercase">Approved</span>
                                <p>&nbsp;</p>

                                <!-- <a href="#" class="btn btn-primary"></a> -->
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                                    Make Quick Transfer
                                </button>

                                <!-- Vertically centered scrollable modal -->
                                <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                                    <!-- Modal -->
                                    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h1 class="modal-title fs-3" id="exampleModalLabel">Quick Transfer</h1>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <p>
                                                        In order to make a Quick Transfer a token is required, please select your account already registed and you have to put the token below input box.
                                                    </p>
                                                    <h4>
                                                        Transfer Now.
                                                    </h4>
                                                    <form action="./processing.php" method="post">
                                                        <div class="mb-3">
                                                            <label for="formGroupExampleInput" class="form-label">Select Account</label>
                                                            <select class="form-select" id="specificSizeSelect">
                                                                <option selected>Choose...</option>
                                                                <option value="1">Checkings</option>
                                                                <option value="2">Savings</option>
                                                                <!-- <option value="3">Three</option> -->
                                                            </select>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label for="formGroupExampleInput2" class="form-label">Destination Account</label>
                                                            <input type="number" class="form-control" id="formGroupExampleInput2" placeholder="Enter Receiver Account-Number">
                                                        </div>
                                                        <div class="mb-3">
                                                            <label for="formGroupExampleInput3" class="form-label">Routing Number</label>
                                                            <input type="number" class="form-control" id="formGroupExampleInput3" placeholder="Enter Routing Number">
                                                        </div>
                                                        <div class="mb-3">
                                                            <label for="formGroupExampleInput4" class="form-label"> Bank Name</label>
                                                            <input type="text" class="form-control" id="formGroupExampleInput4" placeholder="Enter Bank Name">
                                                        </div>
                                                        <div class="mb-3">
                                                            <label for="formGroupExampleInput5" class="form-label">Enter Token</label>
                                                            <input type="textr" class="form-control" id="formGroupExampleInput5" placeholder="Enter Token">
                                                        </div>
                                                        <div class="form-check">
                                                            <input class="form-check-input" type="checkbox" id="autoSizingCheck2">
                                                            <label class="form-check-label text-start" for="autoSizingCheck2">
                                                                Save beneficiary
                                                            </label>
                                                        </div>

                                                        <p>
                                                            <cite>Request Token</cite>
                                                            <b> Note: </b> Address should be ERC20-compliant.
                                                        </p>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                    <!-- <button type="button" class="btn btn-primary">Make Transfer</button> -->
                                                    <button type="submit" class="btn btn-primary" data-bs-toggle="popover" data-bs-placement="top" data-bs-custom-class="custom-popover" data-bs-title="Loading..." data-bs-content="Your Account is under-review, Please try agin later or contact support!">
                                                        Make Transfer
                                                    </button>
                                                </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="col-md-4 themed-grid-col p-2">
                        <div class="card">
                            <h5 class="card-header text-info-emphasis">Your Account Info.</h5>
                            <div class="card-body">
                                <h5 class="card-title"> Account Name: <label class="me-1"> <?php echo ($_SESSION["USER"]['first_name'])  ?> </label> <?php echo ($_SESSION["USER"]['last_name'])  ?></h5>
                                <span class="card-text">
                                    <b>Account Number:</b> 644765858755
                                </span><br>
                                <span>
                                    <b>Routing Number: </b> 031101280
                                </span><br>
                                <p>
                                    <b>Account-type: </b> Checkings.
                                </p>
                                <span>
                                    <b>Bank-Sort: </b> 21-29-11.
                                </span>
                                <!-- <a href="#" class="btn btn-primary">Go somewhere</a> -->
                            </div>
                        </div>
                    </div>
                </div>

                <br />
                <div class="row">
                    <div class="col-lg-7 p-2">
                        <div class="card mb-3" style="max-width: 730px;">
                            <div class="row g-0">
                                <div class="col-md-4">
                                    <img src="./images/reuters pic.jpg" class="img-fluid rounded-start" alt="reuters">
                                </div>
                                <div class="col-md-8">
                                    <div class="card-body">
                                        <h5 class="card-title fw-bold text-info-emphasis">Promotional Offers</h5>
                                        <p class="card-text">
                                            Register your e-mail address to get express delivery of the latest offers and earn a chance to win fabulous prize.
                                        </p>
                                        <p class="card-text"><small class="text-muted">
                                                To protect the environment and reduce paper consumption, please opt for e-statement service.
                                            </small>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-5 p-2">
                        <div class="card">
                            <div class="card-body">
                                <table class="table">
                                    <thead class="fw-bold text-info-emphasis">
                                        <tr>
                                            <th scope="col">Recent Transactions</th>
                                            <th scope="col">&nbsp;</th>
                                            <th scope="col">&nbsp;</th>
                                            <th scope="col"> <a href="./transaction.php">VIEW ALL <i class="fa-regular fa-greater-than"></i></a></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <th scope="row"><b>GLHUm4v2YU</b>
                                                <p class="text-body-tertiary">25 Feb, 2023 04:41pm</p>
                                            </th>
                                            <!-- <td>&nbsp;</td> -->
                                            <td>&nbsp;</td>
                                            <td><b>252,000.00 USD</b>
                                                <p class="text-body-tertiary">3,803,099.00 USD</p>
                                            </td>
                                            <td class="text-info-emphasis text-center align-middle fs-1"><i class="fa-regular fa-circle-check"></i></td>
                                        </tr>
                                        <tr>
                                            <th scope="row"><b>TXNZm4vxMP</b>
                                                <p class="text-body-tertiary"> 05 Feb, 2023 11:41am</p>
                                            </th>
                                            <!-- <td>&nbsp;</td> -->
                                            <td>&nbsp;</td>
                                            <td><b>172,740.00 USD</b>
                                                <p class="text-body-tertiary">3,503,899.00 USD</p>
                                            </td>
                                            <td class="text-info-emphasis text-center align-middle fs-1"><i class="fa-regular fa-circle-check"></i></td>
                                        </tr>
                                        <tr>
                                            <th scope="row"><b>TRFm4vs2JB</b>
                                                <p class="text-body-tertiary"> 19 Jan, 2023 06:48pm</p>
                                            </th>
                                            <!-- <td>&nbsp;</td> -->
                                            <td>&nbsp;</td>
                                            <td><b>102,900.00 USD</b>
                                                <p class="text-body-tertiary">3,103,899.00 USD</p>
                                            </td>
                                            <td class="text-info-emphasis text-center align-middle fs-1"><i class="fa-regular fa-circle-check"></i></td>
                                        </tr>
                                        <!-- <tr>
                                            <th scope="row">3</th>
                                            <td colspan="2">Larry the Bird</td>
                                            <td>@twitter</td>
                                        </tr> -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div><br>
        <!-- --------- ========= ------  -->

        <!-- -------- Footer ------------ -->
        <nav class="navbar fixed-bottom bg-body-tertiary">
            <div class="container-fluid">
                <div class="navbar-brand" href="#">
                    <label> <a href="#">Information.</a></label>
                    <label> <a href="#"> FAQ. </a></label>
                    <label><a href="#"> Privacy & Policy.</a></label>
                </div>
                <a class="navbar-brand" href="#"> &nbsp;</a>
                <div class="navbar-brand" href="#">
                    <label> <i class="fa-regular fa-copyright"></i> 2023 First Citizen Group Bank </label>
                    <label>ALL RIGHT RSERVED.</label>
                </div>
            </div>
        </nav>
    </div>

    <!-- ------ Conflict detect against Awesome fonts ------ -->
    <script type="text/javascript" src="https://example.com/fontawesome/v6.3.0/js/conflict-detection.js">
    </script>
    <!-- bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js" integrity="sha384-mQ93GR66B00ZXjt0YO5KlohRA5SY2XofN4zfuZxLkoj1gXtW8ANNCe9d5Y3eG5eD" crossorigin="anonymous"></script>
</body>

</html>